if [ -e /home/container/setup/firstRun ]; then
    export PATH=$PATH:/home/container/commands

    chmod +x /home/container/commands/*

    ntfy serve --config /home/container/data/server.yml &

    bash
else
    cat /home/container/info.txt

    touch /home/container/setup/firstRun
    
    exit
fi;